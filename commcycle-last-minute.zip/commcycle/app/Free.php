<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Free extends Model
{
    //

    protected $table = 'free';
}
