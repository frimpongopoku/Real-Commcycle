<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LadyBorder extends Model
{
    protected $table = 'ladyBorders';
}
