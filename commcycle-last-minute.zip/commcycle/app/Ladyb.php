<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ladyb extends Model
{
    protected $fillable=['Price'];
}
