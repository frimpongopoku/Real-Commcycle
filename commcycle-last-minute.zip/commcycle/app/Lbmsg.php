<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lbmsg extends Model
{
    //
}
