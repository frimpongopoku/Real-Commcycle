<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoPicShop extends Model
{
    //
     protected $table = 'shopfree';
}
