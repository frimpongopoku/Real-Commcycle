<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lbNews extends Model
{
    protected $table = 'news'; 

    protected $fillable =['News']; 
    
}
