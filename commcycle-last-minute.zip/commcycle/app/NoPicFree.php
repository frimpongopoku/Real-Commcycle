<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoPicFree extends Model
{
    //
    protected $table='freefree';
}
