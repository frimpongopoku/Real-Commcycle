<?php 

namespace App; 


use Illuminate\Database\Eloquent\Model; 

class DesignRequest extends Model { protected $table = "design_request";}