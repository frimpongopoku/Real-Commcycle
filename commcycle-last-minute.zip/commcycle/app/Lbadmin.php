<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lbadmin extends Model
{
    protected $fillable=['Name','Email','Password'];
}
