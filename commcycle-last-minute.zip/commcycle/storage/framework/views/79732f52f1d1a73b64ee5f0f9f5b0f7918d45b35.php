<?php if(Session::has('admin')): ?>
		<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(Session::get('admin') == $admin->name.":".$admin->password ): ?>
				

				<?php $__env->startSection('content'); ?>
					<div style="margin-top:40px;"></div>
					<h3 class="text-center solid-text-light">Transactions</h3>
					<hr>
					<div class="container">
						<div class="row">
							<div class="col-md-12 col-lg-9 col-sm-12 col-xs-12" style='height:600px;'>
								<!--Table-->
							<table class="table">
							
							    <!--Table head-->
							    <thead class="blue-grey lighten-4">
							        <tr>
							            <th>#</th>
							            <th>ADMIN</th>
							            <th>ITEMS</th>
							            <th>SHOP</th>
							            <th>CASH</th>
							        </tr>
							    </thead>
							    <!--Table head-->
							
							    <!--Table body-->
							    <tbody>
							    	<?php $__empty_1 = true; $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								        <tr>
								            <th scope="row"><?php echo e($t->id); ?></th>
								            <td><?php echo e($t->adminName); ?></td>
								            <td><?php echo e($t->item); ?></td>
								            <td><?php echo e($t->shop); ?></td>
								            <td class='text text-success'>+ <?php echo e($t->money); ?></td>

								        </tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
									 <th scope="row">1</th>
								            <td>No Transaction yet</td>
								            <td>No Transaction yet</td>
								            <td>No Transaction yet</td>
								            <td>No Transaction yet</td>

								        
							        <?php endif; ?>
							           
							            <tr>
								            <th scope="row">TOTAL</th>
								            <td></td>
								            <td></td>
								            <td></td>
								            <td class='btn btn-success'>
								            	<?php  
								            		$number =0;
								            		foreach($trans as $d) {
								            			$number = $number + $d->money;
								            		
								            		}
								            		echo $number;
								            		
								            	 ?>
								            
								            
								            </td>
							            </tr>

							        
							    </tbody>
							    <!--Table body-->
							
							</table>
							<!--Table-->
							
											
							</div> 
						</div> 
					</div> 
				<?php $__env->stopSection(); ?> 
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?>
					
<?php echo $__env->make('admin-pages.admin-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>