<?php 
 {{ symlink('/home/leesoumaya/commcycle/storage/app/public', '/home/leesoumaya/commcycle/public_html/storage') }}