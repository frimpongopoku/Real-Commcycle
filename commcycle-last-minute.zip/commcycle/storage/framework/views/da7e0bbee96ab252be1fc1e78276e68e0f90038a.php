<div>
								
	<?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p style='margin:2px;padding:5px; border:solid 0px orange; border-left-width:2px; margin-top:3px;'>
									
									
				<small class='text text-info'><b><?php echo e($comment->name); ?></b></small><br>
						<span style='font-style:italic; font-size:0.7em;color:black;'><b><?php echo e($comment->comment); ?></b></span>
										
									</p>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
