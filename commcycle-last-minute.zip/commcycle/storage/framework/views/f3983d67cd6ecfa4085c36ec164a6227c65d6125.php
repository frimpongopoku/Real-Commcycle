<?php $__env->startSection('title'); ?> 
	Security Admin
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

	<div style=' margin-top:100px;'></div>
	<center><h1 style='margin-bottom:400px; background:white;'>Welcome Gibson, start working bitch!</h1></center>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin-pages.admin-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>