 
<?php $__env->startSection('title'); ?>
	<?php echo e($found->Item); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('graphs'); ?> 
    <meta property ="og:url" content="http://commcycle.co/item-view/<?php echo e($found->id); ?>"/> 
    <meta property ="og:type" content="website"> 
    <meta property="og:title" content="<?php echo e($found->Item); ?>"/>
    <meta property="og:image" content="http://commcycle.co/<?php echo e($found->Pics); ?>"/>
    <meta property="og:image:width" content="620" />
    <meta property="og:image:height" content="541" />
    <meta property="og:fb:app_id" content="168780823705676" />
    <meta property="og:description" content="<?php echo e($found->info); ?>" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?> 
	<div class='container' style='height:100%;'> 
		<div class='row'> 
			<div class='col-lg-10 col-md-10 col-sm-10 col-md-offset-1 col-xs-12' style='margin-top:70px;'> 
				<div class=''>
					<img  class='img-fluid z-depth-2'src='<?php echo e(asset("$found->Pics")); ?>' style='height:70%; width:90%'>
				</div>
				<div> 
					<h3><?php echo e($found->Item); ?></h3>
					<h4 class=''><?php echo e($found->Brand); ?></h4>
					<p><?php echo e($found->Info); ?></p>
						 		
					
					<hr style=''>
									
					<p><?php echo e($found->info); ?></p>
					

				</div>
			</div>
						
		
		</div>
	</div>
	<div style='margin-bottom:300px;'> 
	</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.MDmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>