	<?php if(Session::has('admin')): ?>
		<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(Session::get('admin') == $admin->name.":".$admin->password ): ?>
				
				<?php $__env->startSection('content'); ?>
					<h1 class="section-title solid-text-light text-center">
							<span style="color:deeppink;">WEL</span><span style="color:orange;">CO</span><span style="color:cyan;">ME</span>-<?php echo e(explode(":",Session::get('admin'))[0]); ?>

						</h1>
						<div class="row">
							    <div class="col-md-9 col-lg-9 col-xs-12  col-sm-12">
							        <div class="list-group fixed" style="min-height:300px; max-height:700px;overflow-y:scroll">
							            <a class="list-group-item active solid ">
							                <h4 class="list-group-item-heading solid-text-light"><span class="fa fa-envelope"></span> Messages from people</h4>
							                <p class="list-group-item-text"></p>
							            </a>
							            <?php $__empty_1 = true; $__currentLoopData = $msgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								            <a class="list-group-item">
								                <h4 class="list-group-item-heading label label-success"><i class="fa fa-envelope"></i> <?php echo e($msg->Name); ?> <small class="text text-success pull-right"><?php echo e($msg->created_at->diffForHumans()); ?></small></h4>
								                <p class="list-group-item-text" style="max-width:99%; overflow-x:scroll;"><?php echo e($msg->Message); ?></p>
								            </a>
								        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								        	<a class="list-group-item">
							                <h4 class="list-group-item-heading label label-warning"><i class="fa fa-envelope-o"></i> No msgs</h4>
							                <p class="list-group-item-text text text-warning">You dont have any messages yet!</p>
							            </a>
								        <?php endif; ?>
							        </div>
							    </div>
							    <!-- /.col-sm-4 -->	

							    <div class="col-md-9 col-lg-9 col-xs-12  col-sm-12">
							        <div class="list-group fixed" style="min-height:200px; max-height:700px;overflow-y:scroll">
							            <a  class="list-group-item active solid">
							                <h4 class="list-group-item-heading solid-text-light"><span class="fa fa-edit"></span> Logs</h4>
							                <p class="list-group-item-text"></p>
							            </a>
							             <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								            <a  class="list-group-item">
								                <h4 class="list-group-item-heading label label-warning"><i class="fa fa-edit"></i> <?php echo e($log->created_at->diffForHumans()); ?> </h4>
								                <p class="list-group-item-text"><?php echo e($log->happening); ?></p>
								            </a>
								        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								        	<a class="list-group-item">
							                <h4 class="list-group-item-heading label label-info"><i class="fa fa-edit"></i> No Logs</h4>
							                <p class="list-group-item-text text text-info">No logs yet!</p>
							            </a>
								        	
								        <?php endif; ?>
							        </div>
							    </div>
							    <!-- /.col-sm-4 -->
						</div>	
				<?php $__env->stopSection(); ?> 
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
			<div class="container" style="margin-top:300px">
				<div class="row col-md-6 col-lg-6 col-md-offset-3 col-sm-12 col-xs-12"> 
					<div class="alert alert-warning clearfix solid solid-text-light" style="background: deeppink; color:cyan;">
						<p>You are not signed in as an admin. Please do so :) <a class="btn btn-success pull-right solid-two" href="<?php echo e(route('admin.signin')); ?>" style="background:orange;">Sign in </a></p>
					</div>
				</div>
			</div>
		
    <?php endif; ?>

	


<?php echo $__env->make('admin-pages.admin-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>