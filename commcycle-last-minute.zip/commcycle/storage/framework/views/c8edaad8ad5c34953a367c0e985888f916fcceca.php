 

<?php $__env->startSection('content'); ?> 

<div style='margin-top:70px;'></div> 
<div class='container' style='min-height:600px; background-color:white; overflow-x:hidden;'>
	<center><h1>Chill, something cool is happening. You will love it</h1></center>	 
</div>


<?php $__env->stopSection(); ?> 

<?php $__env->startSection('custom-js'); ?> 
	<script>
				
		<?php if(Session::has('article-img-link')): ?>
			var theLink ="<?php echo e(Session::get('article-img-link')); ?>";
	
		<?php endif; ?>
		
		
		$('[data-toggle="popover"]').popover();
		$('#pin-generator').on('click',function(e){
			e.preventDefault();
		});
	</script>
	<script src="<?php echo e(asset('js/artificial/blog.js')); ?>"></script>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('admin-pages.admin-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>