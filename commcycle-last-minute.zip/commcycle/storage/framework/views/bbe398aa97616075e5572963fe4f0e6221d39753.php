 


<?php $__env->startSection('title'); ?> 
Commy-Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
<div style='margin-top:80px;'></div>
<!-- ############################################################### commcycle ADS ################################################################ -->
<div class='container'> 
		<div class='row'> 
			<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12' style=''> 
				<div class='thumbnail phone-mode-show' style='height:100px;'> 
					
				<?php $__currentLoopData = array_slice($commAddSet,7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<img src="<?php echo e(asset($row['Pics'])); ?>" class='pull-left  img-thumbnail img-responsive' style='height:80px; width:100px;margin-right:3px;'>
					<?php break; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
	<a class='btn btn-sm btn-primary solid-two-light' id='try' onclick='' href='http://commcycle.co/commcycleshop' target='_blank' style='margin:10px;margin-top:25px;width:100%'>See <i class='fa fa-forward'></i></a> <br>
						
				</div>
					<br>
					<div class='thumbnail pc-mode' style='height:100px;'> 
					
							<?php $__currentLoopData = $commAddSet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<img src="<?php echo e(asset($row['Pics'])); ?>" class='pull-left  img-thumbnail img-responsive' style='height:80px; width:100px;margin-right:3px;'>
								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
				<a class='btn btn-sm btn-primary solid-two-light' id='try' onclick='' href='http://commcycle.co/commcycleshop' target='blank' style='margin:10px;margin-top:25px;border-radius:100%'><i class='fa fa-forward'></i></a> 
									
					</div>			
	    			</div>
    			</div>
    		</div>
    	</div>

<!-- ##################################################### commcycle ADS END ############################################################### -->
	<div class='container'> 
		<div class='row'> 
<!-- ##################################################### ARTICLE BEGINNING ############################################################### -->
			<div class='col-lg-8 col-md-8 col-sm-8 col-xs-12' style='margin-bottom:200px;'>
				
				<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				
					<?php if($article->extras == 2): ?>
						<div >
							<h1 clas='solid-text-light' style='font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, "AppleGothic", sans-serif;font-size:4em;'><?php echo e($article->tagline); ?></h1>
								<p style=''><b><?php echo e($article->semiTag); ?></b></p>
								<small><b>Posted:</b> <?php echo e($article->created_at->diffForHumans()); ?> | <b>Updated:</b> <?php echo e($article->updated_at->diffForHumans()); ?>

								</small>
						</div>
							<center><img src="<?php echo e(asset($article->Image)); ?>" class='solid-two-light' style='height:90%px; width:100%;margin:15px 0px;'></center>
														
			<!-- ########################################## SHOW FIRST POST WITH EXTRA PICS##################################### -->
			
			<?php 
				$txtArray = explode('<-->',$article->Text);
				$imgList = explode(',',$article->extraPics);
				foreach($txtArray as $index => $text){
					echo "<p style=' white-space:pre-wrap;'>$text</p>";
					//echo "<pre style=' background:white; border: solid 0px black; padding:15px; overflow-x:scroll;max-width:100%'>$text</pre>";
					echo "<img style='height:75%; width:100%;margin-top:10px; margin-bottom: 10px;'src='$imgList[$index]'>";
				} 
			
			 ?>

			<!-- ################################# END OF SHOW  ######################################### -->
			
												
						<!-- SHARE AND COMMENT PANE --> 
						<div class='thumbnail clearfix ' style='height:50px;padding:5px;'>
							<button class='btn-sm btn btn-default pull-left' style='background:#3B5998; color:white;' onclick='theBlogShare("commcycle.co/commy-article/<?php echo e($article->id); ?>")'><i class='fa fa-facebook'></i></button>
							<div class='pull-right'>
								<small><?php echo e(count($article->comments)); ?> Comment<?php echo e(count($article->comments) ==1 ? '' : 's'); ?> </small>
								<button class='btn btn-sm btn-default solid-two-light comment-trigger' style='color:white; background-color:#585858' data-toggle='modal' data-id='<?php echo e($article->id); ?>' data-target='#comment-box-<?php echo e($article->id); ?>'><i class='fa fa-comment'></i></button>
							</div>	
						</div>
						<!-- END AD --> 
						<div class='thumbnail solid-two-light' style='border:solid 3px deeppink; height: 230px; max-height:250px; overflow-y:scroll; '>
							<center><small class='text text-danger'>Check out Lady-B Items</small></center>
							<?php $__currentLoopData = $lbAddSet2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
									<?php break; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<a class='btn btn-sm btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%' href='http://commcycle.co/ladyBshop' target='blank'>See <i class='fa fa-forward'></i></a> 
						</div>
						<!-- COMMENT MODAL --> 
						
						<div class='modal fade' id='comment-box-<?php echo e($article->id); ?>'> 
							<div class='modal-dialog modal-md' style='border-radius:0px;'> 
								<div class='modal-content'> 
									<div class='modal-header' style='color:black; background:deeppink'> 
										<h2 class='modal-title'>Comments</h3>
									</div>
									<div class='modal-body ' id='modal-body-<?php echo e($article->id); ?>' style=' max-height:250px; overflow-y:scroll;' >
										
										<div>
										
											<?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<p style='margin:2px; padding:5px; border:solid 0px orange; border-left-width:2px; margin-top:3px;'>
											
											
												<small><b><?php echo e($comment->name); ?></b></small><br>
												<span style='font-style:italic; font-size:0.7em;color:black;'><b><?php echo e($comment->comment); ?></b></span>
												
											</p>
											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									
										
		
									</div> 
									<div class='modal-footer clearfix' style=''> 
										<input type='name' id='commenter-name-<?php echo e($article->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:100%;' placeholder='your name or email' required> <br>
										<button class='btn btn-default pull-right solid-two-light comment-button' data-id='<?php echo e($article->id); ?>' id='' style='margin-top:5px;' ><span class='glyphicon glyphicon-send'></span></button>
										<input type='name' id='comment-boxy-<?php echo e($article->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:80%; margin-top:5px;' placeholder='comment..'>
		
										
									</div> 
								</div> 
							</div> 
						</div>
		<!--  COMMENT END -->
					
					<?php else: ?>
						<div >
							<h1 clas='solid-text-light' style='font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, "AppleGothic", sans-serif;font-size:4em;'><?php echo e($article->tagline); ?></h1>
								<p style=''><b><?php echo e($article->semiTag); ?></b></p>
								<small><b>Posted:</b> <?php echo e($art->created_at->diffForHumans()); ?> | <b>Updated:</b> <?php echo e($article->updated_at->diffForHumans()); ?>

								</small>
						</div>
							<center><img src="<?php echo e(asset($article->Image)); ?>" class='solid-two-light' style='height:80%px; width:100%;'></center>
							<p style='font-size:0.9'><?php echo e(substr($article->Text,0,400)); ?></p>
							
							
						<!-- MIDDLE TEXT ADVERTISMENT --> 
						<div class='thumbnail solid-two-light phone-mode-show clearfix' style='border:solid 3px deeppink; height: 230px;max-height:250px; overflow-y:scroll; '>
						     <!-- SHOW THIS ON MOBILE DEV --> 
						 <center><small class='text text-danger'>Check out Lady-B Items</small></center>
							<?php $__currentLoopData = $lbAddSet1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
									<?php break; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php break; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<a class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%' href='http://commcycle.co/ladyBshop' target='blank'>See <i class='fa fa-forward'></i></a> 
						
												
						</div>
						<div class='thumbnail solid-two-light pc-mode' style='border:solid 3px deeppink; height: 230px;max-height:250px; overflow-y:scroll; '>
							<center><small class='text text-danger'>Check out Lady-B Items</small></center>
							<?php $__currentLoopData = $lbAddSet1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
									<?php break; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<a class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%'  href='http://commcycle.co/ladyBshop' target='blank'>See <i class='fa fa-forward'></i></a> 
						</div>
						
						<!--Now show the rest of the article -->
						<p><?php echo e(substr($article->Text,400)); ?></p>
						
						<!-- SHARE AND COMMENT PANE --> 
						<div class='thumbnail clearfix ' style='height:50px;padding:5px;'>
							<button class='btn btn-default pull-left' style='background:#3B5998; color:white;' onclick='share("<?php echo e($article->id); ?>")'><i class='fa fa-facebook'></i></button>
							<div class='pull-right'>
								<small><?php echo e(count($article->comments)); ?> Comment<?php echo e(count($article->comments) ==1 ? '' : 's'); ?> </small>
								<button class='btn btn-default solid-two-light comment-trigger' style='color:white; background-color:#585858' data-toggle='modal' data-id='<?php echo e($article->id); ?>' data-target='#comment-box-<?php echo e($article->id); ?>'><i class='fa fa-comment'></i></button>
							</div>	
						</div>
						<!-- END AD --> 
						<div class='thumbnail solid-two-light' style='border:solid 3px deeppink; height: 230px; max-height:250px; overflow-y:scroll; '>
							<center><small class='text text-danger'>Check out Lady-B Items</small></center>
							<?php $__currentLoopData = $lbAddSet2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
									<?php break; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<a class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%' href='http://commcycle.co/ladyBshop' target='blank'>See <i class='fa fa-forward'></i></a> 
						</div>
						<!-- COMMENT MODAL --> 
						
						<div class='modal fade' id='comment-box-<?php echo e($article->id); ?>'> 
							<div class='modal-dialog modal-md' style='border-radius:0px;'> 
								<div class='modal-content'> 
									<div class='modal-header' style='color:black; background:deeppink'> 
										<h2 class='modal-title'>Comments</h3>
									</div>
									<div class='modal-body ' id='modal-body-<?php echo e($article->id); ?>' style=' max-height:250px; overflow-y:scroll;' >
										
										<div>
										
											<?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<p style='margin:2px; padding:5px; border:solid 0px orange; border-left-width:2px; margin-top:3px;'>
											
											
												<small><b><?php echo e($comment->name); ?></b></small><br>
												<span style='font-style:italic; font-size:0.7em;color:black;'><b><?php echo e($comment->comment); ?></b></span>
												
											</p>
											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									
										
		
									</div> 
									<div class='modal-footer clearfix' style=''> 
										<input type='name' id='commenter-name-<?php echo e($article->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:100%;' placeholder='your name or email' required> <br>
										<button class='btn btn-default pull-right solid-two-light comment-button' data-id='<?php echo e($article->id); ?>' id='' style='margin-top:5px;' ><span class='glyphicon glyphicon-send'></span></button>
										<input type='name' id='comment-boxy-<?php echo e($article->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:80%; margin-top:5px;' placeholder='comment..'>
		
										
									</div> 
								</div> 
							</div> 
						</div>
		<!--  COMMENT END -->
		
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				
				<?php endif; ?>
				
			</div><!-- /.End col-8 -->
<!-- ##################################################### ARTICLE ENDING ############################################################### -->


		
		
		
		
		
		
		
<!-- ##################################################### ARTICLE SHOP ADS BEGINING ############################################################## -->
								
			<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'> 
			
				<?php $__currentLoopData = $shopAddSet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					  <div class='thumbnail  clearfix' style='padding:2px; border:solid 0px #585858;border-radius:0px; border-bottom-width:2px;'>
						<img src="<?php echo e(asset($row['Pics'])); ?>" class=' img-thumbnail pull-left img-responsive' style='height:80px; width:100px;margin-right:3px;'>
					<article>
						<p style='font-size:0.9em;margin-bottom:0px;'><b><?php echo e($row['Item']); ?></b></p>
						<p style='font-size:0.9em;margin-bottom:0px;'>Category: <?php echo e($row['Category']); ?></p>
						<p style='font-size:0.9em;margin-bottom:0px; color:green; font-family:sans-serif;'><b>ZAR <?php echo e($row['Price']); ?></b>
						<small>Uploaded: <?php echo e($row['created_at']->diffForHumans()); ?></small>
						</p>
					</article>
					<a class='btn btn-success pull-right solid-two-light' onclick='adverts(<?php echo e($row["id"]); ?>,5)' style='border-radius:100%; border:solid 2px white;'><i class='fa fa-forward'></i></a>
					</div>
					<?php break; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				<!--SUBSCRIBE PART -->
				<div class='thumbnail solid-two-light clearfix'>
					<center><small >Subscribe to get updates on latest posts and important information!</small> </center>
					<div class='form-group clearfix'> 
						<input type='email' class='form-control' style='width:100%'> 	 
					</div>
					<div class='form-group pull-right'> 
						<input type='submit' placeholder='Email' value='Subscribe' class='btn btn-sm btn-info pull-right solid-two-light'>		 
					</div>
				</div>
				
				<!-- NEXT ARTICLE STUFF --> 
			<div class='thumbnail clearfix'>
				<div class='pull-right'>
					<button class='btn btn-default' id='more-button' data-main-id='' data-toggled='true'><span class='glyphicon glyphicon-plus'></span></button>
				</div> 
				<p>See more articles</p> 
			
			</div>
			<div id ='more-pane' class='thumbnail' style='max-height:800px; width:100%;height:600px; overflow-y:scroll'> 
				<div class="list-group">
				
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <a href="/commy-article/<?php echo e($article->id); ?>" class="list-group-item list-group-item-action flex-column align-items-start ">
					    <div class="d-flex w-100 justify-content-between">
					      <p class="mb-1 text text-success"><b><?php echo e($article->tagline); ?></b></p>
					      <small><?php echo e($article->created_at->diffForHumans()); ?> </small>
					    </div>
					   <small class="mb-1"><span style='font-size:3em'>"</span> <?php echo e($article->semiTag); ?> <span style='font-size:3em'>"</span> </small><br>
					    <small><?php echo e(count($article->comments) ==1 ? count($article->comments). ' comment ' : count($article->comments). ' comments '); ?></small>
					  </a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 </div>
			</div>
		
		</div>

<!-- ##################################################### ARTICLE SHOP ADS END ############################################################### -->

		</div><!-- END ROW --> 
	</div><!-- END SECOND CONTAINER --> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?> 
	<script src="<?php echo e(asset('js/artificial/pub-blog.js')); ?>"></script>
	
	<script> 
		function adverts(id,paginationNumber){
			$.ajax({
				method:'get', 
				url:'/page-number/'+paginationNumber + '/'+id
			}).done(function(response){
				var pageNumber = response; 
				 window.open('http://commcycle.co/shop?page='+pageNumber,'_blank');
				
			}); 					
		};
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.blognav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>