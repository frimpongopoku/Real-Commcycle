<?php if(Session::has('lb-admin')): ?>
        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Session::get('lb-admin') == $admin->Name.":".$admin->Password ): ?>
                

                <?php $__env->startSection('content'); ?>
                <div style="margin-top:55px;"></div>
                <div class="row">
                    <div class="col-lg-9 col-md-9 " id="thetable">
                        <h2 class="solid-text-light text-center"><span style="color:deeppink;">LADYB</span> <span style="color:orange;">Ord</span><span style="color:cyan;">ers</span> <i class="fa fa-shopping-cart" style="color:lime;"></i> </h2>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped" >
                                <thead>
                                    <tr>
                                        <th class="text text-info solid-text-light">Name</th>
                                        <th class="text text-info solid-text-light">Email of orderer</th>
                                        <th class="text text-warning solid-text-light">Address</th>
                                        <th class="text text-warning solid-text-light">Items (item - number - price)</th>
                                        <th class="text text-success solid-text-light">Total price</th>
                                        <th class="text text-success solid-text-light">Time of order</th>
                                        <th class="text text-danger solid-text-light">Delete</th>
                                     </tr>
                                </thead>
                                <tbody>
                                    
                                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr class="active">
                                                <td class="text text-info"><?php echo e($order->Name); ?></td>
                                                <td class="text text-info"><?php echo e($order->Email); ?></td>
                                                <td class="text text-warning"><?php echo e($order->Address); ?></td>
                                                <td class="text text-warning"><?php echo e($order->Items); ?></td>
                                                <td class="text text-success"><?php echo e($order->Price); ?></td>
                                                <td class="text text-success"><?php echo e($order->created_at->diffForHumans()); ?></td>
                                        <?php if(Session::get('lb-admin-type')=='superuser'): ?>
                                                <td ><button class="btn btn-danger btn-xs pull-right solid-two" type='button' data-toggle='modal' data-target='#LadyB-order-<?php echo e($order->id); ?>'><i class="glyphicon glyphicon-trash"></i></button></td>
                                        <?php endif; ?>
                                            </tr>
                                <!-- ######################## DELETE LADYB ITEM  CONFIRMATION MODAL ################### --> 
                        <div class='modal fade' id='<?php echo e('LadyB-order-'.$order->id); ?>'>
                            <div class='modal-dialog modal-sm'>
                                <div class='modal-content'> 
                                    <div class='modal-header'> 
                                        <button type='button' class='close' data-dismiss='modal'><span aria-hidden='true'></span>&times;<span class="sr-only"></span></button>
                                        <h3 class='modal-title'>Delete</h3>
                                    </div>
                                    <div class='modal-body'> 
                                        <small><?php echo e(explode(":",Session::get('admin'))[0]); ?>! are you sure you want to delete <b><?php echo e($order->Name); ?>'s </b>order?</small>
                                    </div>
                                    <div class='modal-footer'> 
                                         <a href="ladyB-order-delete/<?php echo e(explode(":",Session::get('lb-admin'))[0]); ?>/<?php echo e($order->id); ?>" class="btn btn-danger pull-right solid-two">Yes</a>  
                                    </div>
                                </div> 
                            </div> 
                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                                            <tr>
                                                <td>Nothing</td>
                                                <td>Nothing</td>
                                                <td>Nothing</td>
                                                <td>Nothing</td>
                                                <td>Nothing</td>
                                                <td>Nothing</td>
                                        <?php if(Session::get('lb-admin-type')=='superuser'): ?>
                                                <td><button type="button" class="btn btn-danger solid" ><span class="fa fa-trash"></span></button></td>
                                        <?php endif; ?>
                                            </tr>
                                        <?php endif; ?>
                                        
                                </tbody>
                            </table>
                        </div>
                    </div>

                <style>
                    #thetable{
                        min-height:500px; 
                        max-height:800px;
                        overflow-y:scroll;
                    }
                </style>
                <?php $__env->stopSection(); ?>
                <?php break; ?>;
            <?php endif; ?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> 
    <div class="container" style="margin-top:300px">
        <div class="row col-md-6 col-lg-6 col-md-offset-3 col-sm-6 col-xs-6"> 
            <div class="alert alert-warning clearfix solid solid-text-light" style="background: deeppink; color:cyan;">
                <p>You are not signed in as an admin. Please do so :) <a class="btn btn-success pull-right solid-two" href="ladyB-sign-in" style="background:orange;">Sign in </a></p>
            </div>
        </div>
    </div>
<?php endif; ?>    
<?php echo $__env->make('ladyB.ladyB-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>