<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property ="og:url" content="http://commcycle.co/commy-article/<?php echo e($id); ?>"/> 

    <meta property ="og:type" content="website"> 
    <meta property="og:title" content="<?php echo e($art->tagline); ?>"/>
    <meta property="og:image" content="<?php echo e(asset($art->Image)); ?>"/>
    <meta property="og:image:width" content="620" />
	<meta property="og:image:height" content="541" />

    <meta property="og:fb:page_id" content="168780823705676" />
    <meta property="og:description" content="<?php echo e($art->semiTag); ?>" />
        

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <title><?php echo e($art->tagline); ?></title>
   <link rel="icon" type="image" href="<?php echo e(asset('imgs/Social.png')); ?>">

    <!-- Styles -->
   <!-- <link href="<?php echo e(asset('Trev Hookups/css/app.css')); ?>" rel="stylesheet"> -->
    <link href="<?php echo e(asset('Trev Hookups/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Trev Hookups/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Trev Hookups/css/landing-page.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Trev Hookups/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('font/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/artificial/com-global.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/artificial/all.js')); ?>"></script>
    <script src="<?php echo e(asset('js/artificial/facebook.js')); ?>"></script>

</head>
<body>
     <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top solid" role="navigation">
        <div class="container">
        	<center><h3 clas='solid-text-two' style='color:orange; margin:20px;'>Comm<span style='color:cyan'>cycle</span> <span style='color:deeppink;'>Blog</span></h3></center>
         </div>
        <!-- /.container -->

    </nav>

<div style='margin-bottom: 70px;'></div> 

<!-- ############################################################### BODY BEGINNING ################################################################## -->
<!-- ############################################################### commcycle ADS ################################################################ -->

<div class='container'> 
		<div class='row'> 
			<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12' style=''> 
				<div class='thumbnail phone-mode-show' style='height:100px;'> 
					
				<?php $__currentLoopData = array_slice($commAddSet,7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<img src="<?php echo e(asset($row['Pics'])); ?>" class='pull-left  img-thumbnail img-responsive' style='height:80px; width:100px;margin-right:3px;'>
					<?php break; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						
	
	
	<button class='btn btn-primary solid-two-light' id='try' onclick='' style='margin:10px;margin-top:25px;width:100%'>See <i class='fa fa-forward'></i></button> <br>
						
				</div>
					<br>
					<div class='thumbnail pc-mode' style='height:100px;'> 
					
							<?php $__currentLoopData = $commAddSet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<img src="<?php echo e(asset($row['Pics'])); ?>" class='pull-left  img-thumbnail img-responsive' style='height:80px; width:100px;margin-right:3px;'>
								
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									
				
				
				<button class='btn btn-primary solid-two-light' id='try' onclick='' style='margin:10px;margin-top:25px;border-radius:100%'>See <i class='fa fa-forward'></i></button> 
									
					</div>			
	    			</div>
    			</div>
    		</div>
    	</div>

<!-- ##################################################### commcycle ADS END ############################################################### -->


<!-- ##################################################### ARTICLE BEGINNING ############################################################### -->

	<div class='container'> 
		<div class='row'> 
			<div class='col-lg-8 col-md-8 col-sm-8 col-xs-12' style='margin-bottom:200px;'>
			
				<?php if($art->extras ==2): ?>
					<div >
							<h1 clas='solid-text-light' style='font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, "AppleGothic", sans-serif;font-size:4em;'><?php echo e($art->tagline); ?></h1>
								<p style=''><b><?php echo e($art->semiTag); ?></b></p>
								<small><b>Posted:</b> <?php echo e($art->created_at->diffForHumans()); ?> | <b>Updated:</b> <?php echo e($art->updated_at->diffForHumans()); ?>

								</small>
						</div>
							<center><img src="<?php echo e(asset($art->Image)); ?>" class='solid-two-light' style='height:80%px; width:100%;margin:15px;'></center>
														
			<!-- ########################################## SHOW FIRST POST WITH EXTRA PICS##################################### -->
			
			<?php 
				$txtArray = explode('<-->',$art->Text);
				$imgList = explode(',',$art->extraPics);
				foreach($txtArray as $index => $text){
					echo "<p style='white-space:pre-wrap;'>$text</p>";
					echo "<img style='height:75%; width:100%;margin:10px;'src='http://commcycle.co/$imgList[$index]'>";
				} 
			
			 ?>

			<!-- ################################# END OF SHOW  ######################################### -->
			
												
						<!-- SHARE AND COMMENT PANE --> 
						<div class='thumbnail clearfix ' style='height:50px;padding:5px;'>
							<button class='btn btn-default pull-left' style='background:#3B5998; color:white;' onclick='theBlogShare("commcycle.co/commy-article/<?php echo e($art->id); ?>")'><i class='fa fa-facebook'></i></button>
							<div class='pull-right'>
								<small><?php echo e(count($art->comments)); ?> Comment<?php echo e(count($art->comments) ==1 ? '' : 's'); ?> </small>
								<button class='btn btn-default solid-two-light comment-trigger' style='color:white; background-color:#585858' data-toggle='modal' data-id='<?php echo e($art->id); ?>' data-target='#comment-box-<?php echo e($art->id); ?>'><i class='fa fa-comment'></i></button>
							</div>	
						</div>
						<!-- END AD --> 
						<div class='thumbnail solid-two-light' style='border:solid 3px deeppink; height: 230px; max-height:250px; overflow-y:scroll; '>
							<center><small class='text text-danger'>Check out Lady-B Items</small></center>
							<?php $__currentLoopData = $lbAddSet2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
									<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
									<?php break; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<a class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%' href='http://commcycle.co/ladyBshop' target='blank'>See <i class='fa fa-forward'></i></a> 
						</div>
						<!-- COMMENT MODAL --> 
						
						<div class='modal fade' id='comment-box-<?php echo e($art->id); ?>'> 
							<div class='modal-dialog modal-md' style='border-radius:0px;'> 
								<div class='modal-content'> 
									<div class='modal-header' style='color:black; background:deeppink'> 
										<h2 class='modal-title'>Comments</h3>
									</div>
									<div class='modal-body ' id='modal-body-<?php echo e($art->id); ?>' style=' max-height:250px; overflow-y:scroll;' >
										
										<div>
										
											<?php $__currentLoopData = $art->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<p style='margin:2px; padding:5px; border:solid 0px orange; border-left-width:2px; margin-top:3px;'>
											
											
												<small><b><?php echo e($comment->name); ?></b></small><br>
												<span style='font-style:italic; font-size:0.7em;color:black;'><b><?php echo e($comment->comment); ?></b></span>
												
											</p>
											
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									
										
		
									</div> 
									<div class='modal-footer clearfix' style=''> 
										<input type='name' id='commenter-name-<?php echo e($art->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:100%;' placeholder='your name or email' required> <br>
										<button class='btn btn-default pull-right solid-two-light comment-button' data-id='<?php echo e($art->id); ?>' id='' style='margin-top:5px;' ><span class='glyphicon glyphicon-send'></span></button>
										<input type='name' id='comment-boxy-<?php echo e($art->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:80%; margin-top:5px;' placeholder='comment..'>
		
										
									</div> 
								</div> 
							</div> 
						</div>
					</div>
		<!--  COMMENT END -->
				
				
				<?php else: ?>
					<div >
						<h1 clas='solid-text-light' style='font-family: "Avant Garde", Avantgarde, "Century Gothic", CenturyGothic, "AppleGothic", sans-serif;font-size:4em;'><?php echo e($art->tagline); ?></h1>
							<p style=''><b><?php echo e($art->semiTag); ?></b></p>
							<small><b>Posted:</b> <?php echo e($art->created_at->diffForHumans()); ?> | <b>Updated:</b> <?php echo e($art->updated_at->diffForHumans()); ?>

							</small>
					</div>
						<center><img src="<?php echo e(asset($art->Image)); ?>" class='solid-two-light' style='height:80%px; width:100%;'>
						<p style='font-size:0.9'><?php echo e(substr($art->Text,0,400)); ?></p>
						
						
					<!-- MIDDLE TEXT ADVERTISMENT --> 
					<div class='thumbnail solid-two-light phone-mode-show clearfix' style='border:solid 3px deeppink; height: 230px;max-height:250px; overflow-y:scroll; '>
					     <!-- SHOW THIS ON MOBILE DEV --> 
					 <center><small class='text text-danger'>Check out Lady-B Items</small></center>
						<?php $__currentLoopData = $lbAddSet1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
								<?php break; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php break; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<button class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%'>See <i class='fa fa-forward'></i></button> 
					
											
					</div>
					<div class='thumbnail solid-two-light pc-mode' style='border:solid 3px deeppink; height: 230px;max-height:250px; overflow-y:scroll; '>
						<center><small class='text text-danger'>Check out Lady-B Items</small></center>
						<?php $__currentLoopData = $lbAddSet1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
								<?php break; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<button class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%'>See <i class='fa fa-forward'></i></button> 
					</div>
					
					<!--Now show the rest of the article -->
					<p><?php echo e(substr($art->Text,400)); ?></p>
					
					<!-- SHARE AND COMMENT PANE --> 
					<div class='thumbnail clearfix ' style='height:50px;padding:5px;'>
						<button class='btn btn-default pull-left' style='background:#3B5998; color:white;' onclick='theShare("/commy-article/<?php echo e($art->id); ?>")'><i class='fa fa-facebook'></i></button>
						<div class='pull-right'>
							<small><?php echo e(count($art->comments)); ?> Comment<?php echo e(count($art->comments) ==1 ? '' : 's'); ?> </small>
							<button class='btn btn-default solid-two-light comment-trigger' style='color:white; background-color:#585858' data-toggle='modal' data-id='<?php echo e($art->id); ?>' data-target='#comment-box-<?php echo e($art->id); ?>'><i class='fa fa-comment'></i></button>
						</div>	
					</div>
					<!-- END AD --> 
					<div class='thumbnail solid-two-light' style='border:solid 3px deeppink; height: 230px; max-height:250px; overflow-y:scroll; '>
						<center><small class='text text-danger'>Check out Lady-B Items</small></center>
						<?php $__currentLoopData = $lbAddSet2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $lb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<img src="<?php echo e(asset($row['Pics'])); ?>" class=' pull-left solid-two img-responsive' style='height:180px;margin:10px; width:200px;'>
								<?php break; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<button class='btn btn-primary solid-two-light' style='margin:1px;margin-top:45px;border-radius:100%'>See <i class='fa fa-forward'></i></button> 
					</div>
	
				</div><!-- /.End col-8 -->
			<?php endif; ?>
<!-- ##################################################### ARTICLE ENDING ############################################################### -->

<!-- ##################################################### ARTICLE SHOP ADS BEGINING ############################################################## -->
								
			<div class='col-lg-4 col-md-4 col-sm-4 col-xs-12'> 
			
				<?php $__currentLoopData = $shopAddSet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					<?php $__currentLoopData = $shop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
					  <div class='thumbnail  clearfix' style='padding:2px; border:solid 0px #585858;border-radius:0px; border-bottom-width:2px;'>
						<img src="<?php echo e(asset($row['Pics'])); ?>" class=' img-thumbnail pull-left img-responsive' style='height:80px; width:100px;margin-right:3px;'>
					<article>
						<p style='font-size:0.9em;margin-bottom:0px;'><b><?php echo e($row['Item']); ?></b></p>
						<p style='font-size:0.9em;margin-bottom:0px;'>Category: <?php echo e($row['Category']); ?></p>
						<p style='font-size:0.9em;margin-bottom:0px; color:green; font-family:sans-serif;'><b>ZAR <?php echo e($row['Price']); ?></b>
						<small>Uploaded: <?php echo e($row['created_at']->diffForHumans()); ?></small>
						</p>
					</article>
					<button class='btn btn-success pull-right solid-two-light' style='border-radius:100%; border:solid 2px white;'><i class='fa fa-forward'></i></button>
					</div>
					<?php break; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				<!--SUBSCRIBE PART -->
				<div class='thumbnail solid-two-light clearfix'>
					<center><small >Subscribe to get updates on latest posts and important information!</small> </center>
					<div class='form-group clearfix'> 
						<input type='email' class='form-control' style='width:100%'> 	 
					</div>
					<div class='form-group pull-right'> 
						<input type='submit' placeholder='Email' value='Subscribe' class='btn btn-info pull-right solid-two-light'>		 
					</div>
				</div>
				
				<!-- NEXT ARTICLE STUFF --> 
			<div class='thumbnail clearfix'>
				<div class='pull-right'>
					<button class='btn btn-default' id='more-button' data-main-id='<?php echo e($art->id); ?>' data-toggled='true'><span class='glyphicon glyphicon-plus'></span></button>
				</div> 
				<p>See more articles</p> 
			
			</div>
			<div id ='more-pane' class='thumbnail' style='max-height:800px; width:100%;height:600px; overflow-y:scroll'> 
				<div class="list-group">
				
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <a href="/commy-article/<?php echo e($article->id); ?>" class="list-group-item list-group-item-action flex-column align-items-start ">
					    <div class="d-flex w-100 justify-content-between">
					      <p class="mb-1 text text-success"><b><?php echo e($article->tagline); ?></b></p>
					      <small><?php echo e($article->created_at->diffForHumans()); ?> </small>
					    </div>
					   <small class="mb-1"><span style='font-size:3em'>"</span> <?php echo e($article->semiTag); ?> <span style='font-size:3em'>"</span> </small><br>
					    <small><?php echo e(count($article->comments) ==1 ? count($article->comments). ' comment ' : count($article->comments). ' comments '); ?></small>
					  </a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 </div>
			</div>
		
		</div>
	</div><!-- /.row>	
</div>
	<!-- /.container -->




<!-- ##################################################### ARTICLE SHOP ADS END ############################################################### -->

		<!-- COMMENT MODAL --> 
				
				<div class='modal fade' id='comment-box-<?php echo e($art->id); ?>'> 
					<div class='modal-dialog modal-md' style='border-radius:0px;'> 
						<div class='modal-content'> 
							<div class='modal-header' style='color:black; background:deeppink'> 
								<h2 class='modal-title'>Comments</h3>
							</div>
							<div class='modal-body ' id='modal-body-<?php echo e($art->id); ?>' style=' max-height:250px; overflow-y:scroll;' >
								
								<div>
								
									<?php $__currentLoopData = $art->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<p style='margin:2px; padding:5px; border:solid 0px orange; border-left-width:2px; margin-top:3px;'>
									
									
										<small><b><?php echo e($comment->name); ?></b></small><br>
										<span style='font-style:italic; font-size:0.7em;color:black;'><b><?php echo e($comment->comment); ?></b></span>
										
									</p>
									
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							
								

							</div> 
							<div class='modal-footer clearfix' style=''> 
								<input type='name' id='commenter-name-<?php echo e($art->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:100%;' placeholder='your name or email' required> <br>
								<button class='btn btn-default pull-right solid-two-light comment-button' data-id='<?php echo e($art->id); ?>' id='' style='margin-top:5px;' ><span class='glyphicon glyphicon-send'></span></button>
								<input type='name' id='comment-boxy-<?php echo e($art->id); ?>' class='form-control' style='border: solid 0px #282828; border-bottom-width:2px; border-radius:0px; width:80%; margin-top:5px;' placeholder='comment..'>

								
							</div> 
						</div> 
					</div> 
				</div>
<!--  COMMENT END -->



	




<!-- ############################################################### STATUS AREA ################################################################## -->
<section class='footer-for-phone' style='background-color:#282828; color:white;height:100px; padding-right:15px; padding-left:15px;'> 
	<p class='text text-muted solid-text-light' ><span style='color:deeppink'>Com</span><span style='color:cyan'>mcy</span><span style='color:orange'>cle</span> <span>&copy</span> 2017 <button id='' style='color:black;margin-left:25px;'  class='btn btn-default solid-two' data-toggle='popover'  data-placement='top' data-title='Commcycle Links' data-html='true' data-content='
	<div class="col-sm-12" style="width:200px;max-height:200px;overflow-y:scroll "> 
		<ul class="list-group">

                    <a href="#" class="list-group-item">COMMCYCLE SHOP</a>
                    <a href="#" class="list-group-item">SHOP</a>
                    <a href="aboutus" class="list-group-item">ABOUT</a>
                    
                    <a  class="list-group-item active">PATNERS</a>
                    <a href="ladyB-main" class="list-group-item">LADY BURGESSON</a>
                    <a href="#" class="list-group-item">LADY-B SHOP</a>
                    
                    <a  class="list-group-item active">SOCIAL</a>
                    <a href="https://www.fb.com/realcommcycle" target="_blank" class="list-group-item"><span class="fa fa-facebook"><span> FACEBOOK</a>
                    <a href="https://www.instagram.com/commcycle" target="_blank" class="list-group-item"><span class="fa fa-instagram"><span> INSTAGRAM</a>
                    <a href="https://www.twitter.com/commcycle" target="_blank" class="list-group-item"><span class="fa fa-twitter"><span> TWITTER</a>
                   	         </ul>
	        			
	</div>
	
	'><span class='fa fa-bars' ></span></button>
</p> 
</div>
</section>

<!-- PC FOOTER -->
  <section class='footer phone-mode-show' style='background-color:#282828; color:white;height:200px'> 
  	
	  	<div class='col-lg-4 col-md-4 col-sm-12 col-xs-4'> 
	  		<h3 href='#' class='text-center solid-text-light' style='margin:0px;'>CommCycle</h3>
	  			  		<a href='#'>COMMCYCLE SHOP</a>
	  		<hr style='margin:2px;'>
	  		<a href='#'>SHOP</a>
	  		<hr style='margin:2px;'>
	  		<a href='aboutus'>ABOUT</a>
	  		<hr style='margin:2px;'><br>
	  		<p class='text text-muted solid-text-light'><span style='color:deeppink'>Com</span><span style='color:cyan'>mcy</span><span style='color:orange'>cle</span> <span>&copy</span> 2017</p>
	  	</div>
	  	<div class='col-lg-4 col-md-4 col-sm-4 col-xs-4'> 
	  		<h3 href='ladyB-main' class='text-center solid-text-light' style='margin:0px;'>PARTNERS</h3>
	  			  		<a href='#'>LADY BURGESSON</a>
	  		<hr style='margin:2px;'>
	  		<a href='#'>LADY-B SHOP</a>
	  		<hr style='margin:2px;'>
	  		<a href='ladyB-main'>MESSAGE LADY-B</a>
	  		<hr style='margin:2px;'>
	  	</div>
	  	<div class='col-lg-4 col-md-4 col-sm-4 col-xs-4'> 
	  		<h3  class='text-center solid-text-light' style='margin:0px;'>SOCIAL</h3>
	  			  		<a href='https://www.fb.com/realcommcycle' target='_blank'><span class='fa fa-facebook' style='color:cyan; font-size:25px; margin-right:3px;'></span> ACEBOOK</a>
	  		<hr style='margin:2px;'>
	  		<a href='https://www.instagram.com/commcycle' target='_blank' ><span class='fa fa-instagram' style='color:cyan; font-size:25px; margin-right:3px;'></span> INSTAGRAM</a>
	  		<hr style='margin:2px;'>	
	  		<a href='https://www.twitter.com/commcycle' target='_blank'><span class='fa fa-twitter' style='color:cyan; font-size:25px; margin-right:3px;'></span> TWITTER</a>
	  		<hr style='margin:2px;'>
	  	</div>

	  

  <section>	
		

</body>

    <!-- Scripts -->
    <script src="<?php echo e(asset('Trev Hookups/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Trev Hookups/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Trev Hookups/js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(asset('Trev Hookups/js/theme-scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/artificial/pub-blog.js')); ?>"></script>

    
 <style> 

.pink-border{
	border: solid 2px #282828;
}
.Orange{
	background-color:orange;
}
.dropdown-menu >li:hover{
	background-color:cyan;


}
    .solid-type-two{
        box-shadow:6px 9px 0px rgba(0,0,0,0.9);
    }
    .solid{
        box-shadow:0 6px 8px rgba(0,0,0,0.8);

    }
    .solid-two{
        box-shadow:0 3px 4px rgba(0,0,0,0.5);

    }
    .solid-two-light{
        box-shadow:0 2px 2px rgba(0,0,0,0.3);

    }

    .solid-text{
        text-shadow: 0px 4px 8px rgba(0,0,0,0.8);
    }

    .solid-text-light{
        text-shadow: 0px 3px 6px rgba(0,0,0,0.6);

    }
    .solid-text-light-two{
        text-shadow: 0px 2px 4px rgba(0,0,0,0.4);

    }
    .ladyB{
        height:400px;
        width:100%;
    }
    .ladyB-small{
        height:250px;
        width:100%;
    }
    .ladyB-border{
        border:solid 10px black;
        border-left-width:2px;

        border-right-width:2px;
        border-top-left-radius:10px;
        border-top-right-radius:10px;
        border-bottom-width:5;
    

    }
    #phone-lb-image{
    border:solid 1px deeppink;
    border-top-width:5px; 
    border-bottom-width:5px;
    height:400px; 
    width:95%;
    margin:0px;
    }
    .fontlize{
        font-family: Arial, 'Helvetica', sans-serif;
    }

    a{
        text-decoration: none;
    }
     .solid-two{
        box-shadow:0px 3px 4px rgba(0,0,0,0.5);

    }
    
    @media  screen and (max-width:500px){
    .hide-cart-in-phone{
    	opacity:0;
    }
    .phone-cart{
    	display:block;
    }
    .footer-for-phone{
    	display:block;
    }

    .phone-shops-title-new{
    	display:block;
    }
    .phone-shops-title-old{
    	display:none;
    }

    	#phone-text{
    	display:none;
    	}
    	#phone-lady-B-container{
    		display:block; 
    	}
    	    	
    	#phone-lb-text{
    	font-size:25px;
    	}
    	.phone-mode-show{
    		display:block;
    	}
    	.pc-mode{
    		display:none;
    	}
    }
    
    @media  screen and (min-width:500px){
	    .hide-cart-in-phone{
	    	opacity:1;
	    }
	
	        .phone-cart{
	    	display:none;
	    }
	
	    .footer-for-phone{
	    	display:none;
	    }
	
	    	#phone-lady-B-container{
	    		display:none; 
	   	}
	   	.phone-shops-title-new{
	    	display:none;
	    }
	    .phone-shops-title-old{
	    	display:block;
	    }
	    .pc-mode{
    		display:block;
    	}
    	.phone-mode-show{
    		display:none;
    	}


    	    
    }


</style>

 </html>