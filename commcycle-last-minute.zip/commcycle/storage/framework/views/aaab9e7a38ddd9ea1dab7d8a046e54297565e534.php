

<div class="card-group">
					    		<?php $__empty_1 = true; $__currentLoopData = $rev; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							  <div class="card" style='margin-bottom:5px;'>
							        <div class="card-body" style='padding:15px;'>
							            <h5 class="card-title"><b><?php echo e($post->name); ?></b></h5>
							            <p class="card-text"><?php echo e($post->text); ?></p>
							        </div>
							        <div class="card-footer" style='padding:15px;border: solid 2px black;'>
							            <small class=""><?php echo e($post->created_at->diffForHumans()); ?></small>
							        </div>
							    </div>
							 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
							 	<center><p> No reviews have been made at the moment! Be the first </p> </center> 
							 
							 <?php endif; ?>
						</div>
