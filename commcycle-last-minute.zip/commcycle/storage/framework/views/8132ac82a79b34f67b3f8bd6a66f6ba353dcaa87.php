

<div class='container'> 
	<div class='row'> 
	 <div class='col-md-6 col-lg-6'> 
	 	<div class="list-group">
	 	<?php $__currentLoopData = $nameArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  <a href="#"  style='color:green'class="list-group-item"><?php echo e($name); ?></a>
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  				 
		 </div>

	
	 <?php $__currentLoopData = $picturesArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<img src='<?php echo e(asset("$pic")); ?>' class='order-pic solid-two' style='cursor:pointer;margin:5px;width:250px; height:220px;'
		
		
		>
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 </div>
		
	</div>

		
			
	
		

</div>
<script> 
$('[data-toggle="popover"]').popover();
</script>
<style> 
	.order-pic{
		border: solid 3px green; 
		border-radius:10px; 
		padding:5px; 
		background-color:black
		
	
	}.order::hover{
		width: +10px; 
		height: +10px;
		transition: 0.5s;
	
	}
</style>