<div class="list-group">
				
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <a href="/commy-article/<?php echo e($article->id); ?>" class="list-group-item list-group-item-action flex-column align-items-start ">
					    <div class="d-flex w-100 justify-content-between">
					      <p class="mb-1 text text-success"><b><?php echo e($article->tagline); ?></b></p>
					      <small><?php echo e($article->created_at->diffForHumans()); ?> </small>
					    </div>
					    <small class="mb-1"><span style='font-size:3em'>"</span> <?php echo e($article->semiTag); ?> <span style='font-size:3em'>"</span> </small><br>
					    <small><?php echo e(count($article->comments) ==1 ? count($article->comments). ' comment ' : count($article->comments). ' comments '); ?></small>
					  </a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				 </div>