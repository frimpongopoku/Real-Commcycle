<?php $__env->startSection('content'); ?> 
	<div style='margin-top:200px'></>
	<div class= 'container' style='margin-bottom:500px;'> 
		<div class='row'> 
			<center> 
				<h2 class='alert alert-info section-title solid-two solid-text-light'>Just some few days!<br>
				<p>Commcycle will be up and running as soon as school begins! :-) </p></h2>
			</center>
		</div>
	</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>