@extends('main.main')

@section('content') 
	<div style='margin-top:200px'></>
	<div class= 'container' style='margin-bottom:500px;'> 
		<div class='row'> 
			<center> 
				<h2 class='alert alert-info section-title solid-two solid-text-light'>Just some few days!<br>
				<p>Commcycle will be up and running as soon as school begins! :-) </p></h2>
			</center>
		</div>
	</div>



@endsection