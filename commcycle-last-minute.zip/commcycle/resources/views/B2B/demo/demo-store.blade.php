@extends('main.import_header')

@section('title')
    Company Store
@endsection 

@section('content') 
    <div class="container"> 
        <div class="row">
            <div class="col-md-8 col-lg-8 col-md-offset-2">
                <center> 
                    <h2>Some Company's Commcycle Store</h2>
                    <button class="btn btn-primary rounded" data-toggle="modal" data-target="#admin-modal"> <i class="fa fa-dashboard fa-marg-fix"></i> Admin Dashboard</button>
                    <button class="btn btn-default rounded"><i class="fa fa-upload fa-marg-fix"></i>  Upload  </button>
                </center>
                <div style="margin-top:30px">
                    <div class="col-md-6 col-lg-6"> 
                        <div class="thumbnail clearfix" style="padding-bottom:30px;">
                            <img src="{{asset('userImages/599ae3ae3a3a51503322683637-1610249358.jpg')}}" 
                            style="height : 250px !important; width : 100% !important; object-fit: cover !important;margin:0px;margin-bottom:5px;"/>
                            <div class="pull-left" style="padding:5px;"> 
                               <small>Some Item</small>
                                <small style="color:#ccc"> 3 minutes ago</small><br>
                                <small style="color:green"> $ 39900000</small>
                            </div>
                            <div class="pull-right">
                                <button class="btn btn-danger btn-sm rounded" data-toggle="modal" data-target="#delete-modal"><i class="fa fa-trash"></i></button>
                                <button class="btn btn-warning btn-sm rounded"><i class="fa fa-shopping-cart"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id='delete-modal'> 
        <div class="modal-dialog modal-sm"> 
            <div class="modal-content"> 
                <div class="modal-header"> 
                    <button type='button' class='close' data-dismiss='modal'><span aria-hidden='true'></span>&times;<span class="sr-only"></span></button>
                    <p>Delete Item</p>
                </div>
                <div class='modal-body'>
                    <center>    
                        <p>Please verify ownership of this item by posting your access code into the box below.</p>
                        <input type="text" class="form-control" placeholder="xxx-my-upload-xxxaaa" />
                    </center>
                    
                </div>
                <div class='modal-footer'> 
                    <button class='btn btn-danger solid-two' type='button' data-dismiss='modal'>Delete</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id='admin-modal'> 
        <div class="modal-dialog modal-sm"> 
            <div class="modal-content"> 
                <div class="modal-header"> 
                    <button type='button' class='close' data-dismiss='modal'><span aria-hidden='true'></span>&times;<span class="sr-only"></span></button>
                    <p>Admin Authorisation</p>
                </div>
                <div class='modal-body'>
                    <center>    
                        <p>Enter Authorisation code to access the admin pane</p>
                        <input type="text" class="form-control" placeholder="xxx-company-admin-xxxaaa" />
                    </center>
                    
                </div>
                <div class='modal-footer'> 
                    <button class='btn btn-danger solid-two' type='button' data-dismiss='modal'>Log in</button>
                </div>
            </div>
        </div>
    </div>
    
@endsection 

