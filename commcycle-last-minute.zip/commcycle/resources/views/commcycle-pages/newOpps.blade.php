@extends('main.main') 


@section('title') 
	Opportunities
@endsection

@section('content') 
	<div class='container'> 
		<div class='row'>
			<div class='col-lg-6 col-md-6 col-sm-12 col-xs-12 col-md-offset-3'> 
				<div class='thumbnail solid-two' style='margin-top:80px;margin-bottom:400px;background-color:#282828; color:white;border: solid 3px cyan;padding: 25px;'>
					<center>
						<h3 class='solid-text-light'>NEW OPPORTUNITIES FORM</h3>
						<p style='color:white;'>Follow the link below to apply for the opportunities available in commcycle</p>
						<input class='form-control' style='border: solid 2px deeppink; border-radius:0px;width:60%;' value="https://www.surveymonkey.com/r/6QJSGHT" readonly><br>
						<a class=' btn btn-success solid-two solid-text-light' style='width:30%;' href='https://www.surveymonkey.com/r/6QJSGHT' target='_blank'>Go</a> 
					</center>
				</div>
			</div>
		</div>
	</div>
@endsection 
