@extends('admin-pages.admin-nav') 

@section('content') 

<div style='margin-top:70px;'></div> 
<div class='container' style='min-height:600px; background-color:white; overflow-x:hidden;'>
	<div style='margin-left:20%;'>
	 <h3 class='solid-text-light'>Create an article.</h3>
	 	<b>
	 	<small>You might want to follow the few steps below, if you want your article to be saved.</small><br>
	 	<small>1. Upload a picture</small><br>
	 	<small>2. Your tagline/header</small><br>
	 	<small>3. Upload a picture</small><br>
	 	<small>4. The save button will appear as you input words into the big box</small><br>
	 	</b>
	 	<hr style='width:70%; border-width:2px; border-color:cyan; margin-left:0'>
	</div>
	<ul class="nav nav-tabs">
	    <li class="active"><a data-toggle="tab" href="#home">Create Article</a></li>
	    <li><a data-toggle="tab" href="#menu1">Articles</a></li>
	    <li><a data-toggle="tab" href="#settings">Settings</a></li>

	</ul>

	  <div class="tab-content">
	    <div id="home" class="tab-pane fade in active clearfix">
	    	<div class='card' style='width:300px; padding:30px; margin:15px;'>
		    	
		    		    
		    
		      <h4>Upload a cover photo first</h4>
		      
		      <form action='/upload-image' method='post' enctype='multipart/form-data'> 
		       {{csrf_field()}}
		      	@if(Session::has('article-img-status') )
		      
		      	<div id='pic-preview'>
		      	
		      	
		      		<!-- IF THE IMAGE HAS BEEN UPLOADED ALREADY, -->
		      		@if(Session::has('article-img-link'))
		    	      		<img src="{{asset(Session::get('article-img-link'))}}" class='img-thumbnail ' style='height:110px; width:150px;'>
		    	      		<small class='text text-success'><i class='fa fa-check'></i> Picture available for post!</small><br>
		    	      		<a  class='btn btn-danger btn-sm solid-two'  id='del' style='margin-top:15px; width:150px'>Delete Image</a>
		    	      	
		    
		    	      	@else 
		    	      	
		    	      		<!-- A PREVIEW OF THE IMAGE --> 
		    	      		<img src="" class='img-thumbnail pull-left' style='height:110px; width:150px;' alt="img unavailable">
	
		    	      	@endif
		    	      		    	      	
		    	  </div>
		    	  <div id='upload-pane' style='display:none'>
		      		<input type='file' name='image' ><input type='submit' value='upload' class='btn btn-sm btn-warning' style='margin:10px;margin-bottom:0px; margin-left:0px;'>
		      	  </div>
		      	@else 
		      		<div id='upload-pane'>
		      			<input type='file' name='image' ><input type='submit' value='upload' class='btn btn-sm btn-warning' style='margin:10px;margin-bottom:0px; margin-left:0px;'>
		      		</div>
	
		      @endif
		      </form>
		           <!--############################################################################# -->
		      <hr>
		      {{--EXTRA UPLOAD AREA--}}
		      	<small style='text-align:center'><b>Any extra pictures you would like to add to your article</b></small><br>
		      		<small class='text text-info'>NB: You can select multiple images!</small>
		    		 
		    			<form action='/extra-uploads' method='post' enctype='multipart/form-data'>
		    				{{csrf_field()}}
		    				@if(!Session::has('article-extra-img-link-status'))
			    				 <input type='file' name='image[]' multiple><input type='submit' value='upload' class='btn btn-sm btn-default' style='margin:10px;margin-			bottom:0px; margin-left:0px;'>
			    			@else 
			    				<small class='text text-success'><i class='fa fa-check'></i> Extra Pictures are available, and pins have been generated.</small><br>
		    	      		<a  class='btn btn-danger  solid-two'  id='del-ex' style='margin-top:15px; width:150px'>Delete Image</a>
		    	      	

			    			@endif
		    				 <button class='btn  btn-elegant' id='pin-generator'role="button" data-toggle="popover"  title="Pin Generation For Pictures" data-html='true' data-placement='top' data-content=" 
		    				 <div style='max-height:250px; overflow-y:scroll;' class='clearfix'>
		    				 @if(Session::has('article-extra-img-link'))
			    				 @foreach(Session::get('article-extra-img-link') as $index => $path)
			    				 	
			    				 	<img src='{{$path}}' class='float-left img-thumbnail' style='width:60px; height:50px;'alt='placeholder'>
			    				 		<input type='text' class='form-control' value='@--[]--@->{{$index}}'readonly>
	
			    				 @endforeach
			    			@endif
		    				 </div>
		    				 	
		    				 
		    				 ">
		    				 	Generate pin</button>
		    				 			    	      	
		    			</form>
		    		
		    	{{--END OF EXTRA UPLOAD AREA--}}
		  </div>
	      
	      {{-- END OF FORM --}}
		      	<!-- <hr style='width:90%; border-width:2px; margin-left:0'> -->
		      	<small class='text text-success pull-left' style='font-style:Italic; display:none;' id='temp-save'>saving temporarily!</small><br>
		      	
		      	{{-- ARTICLE FORM --}}
	      	   <form action="{{Session::has('edit-basket') ? '/save-edit' : '/save-article'}}" method='get' > 
	      	<div class='col-lg-10 col-md-10 col-sm-10 col-xs-12' style='margin-bottom:10px;'>
	      	
		      		<small class='text text-success' id='tgStatus' style='display:none'><span class='glyphicon glyphicon-flash'></span> Done!</small>
		      		<input type='name' id='tagLine' name='tagLine' class='form-control blog-boxes' value="{{Session::has('edit-basket') ? Session::get('edit-basket')['TagLine'] : '' }}" placeholder='TagLine'>
		      	</div><br>
		      		      	
		        <div class='col-lg-10 col-md-10 col-sm-10 col-xs-12' style='margin-bottom:10px;'>
		      		<small class='text text-success' id='mintgStatus' style='display:none'><span class='glyphicon glyphicon-flash' ></span> Done!</small>
		      		<input type='name' id='miniTagLine' name='miniTagLine' class='form-control blog-boxes' value="{{Session::has('edit-basket') ? Session::get('edit-basket')['SemiTagLine'] : '' }}" placeholder='Mini headline'>
		      	</div>
		      	
		      	 <div class='col-lg-10 col-md-10 col-sm-10 col-xs-12' style='margin-bottom:10px;'>
		      		<small class='text text-success' id='artStatus' style='display:none'><span class='glyphicon glyphicon-flash'></span> Done!</small>
		      		<div class='form-group'>
			      		<textarea rows='15'  id='articleText' name='articleText' class='form-control blog-boxes' placeholder='Article Here' style='width:100%; resize:none;'>{{Session::has('edit-basket') ? Session::get('edit-basket')['Text'] : '' }}</textarea>
			      	</div>
		      	</div>
		      	<input type='hidden' name='image' value="{{Session::has('article-img-link') ? Session::get('article-img-link') : ''}}">
		      		      	
		      	<div class='col-lg-10 col-md-10 col-sm-10 col-xs-12' style='margin-bottom:10px;'>
		      		<div class='thumbnail clearfix '>
		      		
		      		
		      			@if(Session::has('edit-basket'))
		      				<input type='submit' class='btn btn-sm btn-primary solid-two pull-left' id='save' value='Save edits'>
		   	      				<small style='opacity:0.0' class='pull-left'>0</small>
		      				<a href='/cancel-edit'  class='btn btn-danger pull-left solid-two' id='save' style='margin-rigth:10px;'>Cancel</a>
		      			@else 
		      			
			      			<input type='submit' class='btn btn-sm btn-default solid-two' id='save' value='Save Progress'>
			      			<small class='text text-succes' id='save-status'>Make sure you save your progress before you go to bed.</small>
			      			
			      		@endif
			      	</div>
			   
	      	</div>
	      		      	

	      </form>
	     
	    </div>
	    
	    {{-- THE SETTINGS TAB --}}
	    <div id='settings' class='tab-pane fade'> 
	    	<p>Turn on email notifications for comments on the blog?</p>
	    	<button class='btn btn-default' id='on' data-admin="{{ explode(':',Session::get('admin'))[0]}}"
>ON</button>  
	    	<button class='btn btn-default' id='off' data-admin="{{ explode(':',Session::get('admin'))[0]}}"
>OFF</button>    	
	    </div>
	    
	    {{-- THE MENU TAB --}}
	    <div id="menu1" class="tab-pane fade">
	      <p>All articles you have made are available here. You can publish, edit, and delete them through here.</p>
	      @if(count($articles) >10)
	      	<div class='thumbnail' style='width:40%'>{{$articles->links()}}</div>
	      @endif
	      <div class='articles-div'>
	      	@forelse($articles as $article)
	      	
	      		<div class='col-lg-10 col-md-10 col-sm-10 col-xs-12'>
			      <div class='thumbnail clearfix thumb-{{$article->id}}'> 
				    <figure>
				      	<img class='img-responsive pull-left' src="{{asset($article->Image)}}" style='height:100px; width:120px;margin-right:5px;border: solid 2px gray; border-radius:5px; padding:2px;'/>
				    </figure> 
				<article>
				    	<h3>{{$article->tagline}}</h3>
				      	<p><b>{{$article->semiTag}}</b></p>
				      	<p>{{substr($article->Text,0,250)}}</p>
			       </article>
			       
			       
			       	      @if($article->published == 1) 
			       	      	<button class='btn btn-default solid-two unpub-btn' data-id='{{$article->id}}' style='background-color:crimson; color:white; '><span class='glyphicon glyphicon-globe'></span>
 Unpublish</button>
	      	      	 

			       	      @else 
			       	      

			       	      	<button class='btn btn-default solid-two pub-btn' data-id='{{$article->id}}'><span class='glyphicon glyphicon-globe'></span>
			       	      	 Publish</button>
			       	 			       	      	 
			       	      @endif 
			       	      
				      <button class='btn btn-default solid-two' data-toggle='modal' data-target='#preview-modal-{{$article->id}}'>Preview</button>
				       <button class='btn btn-warning solid-two ' data-target='#comment-modal-{{$article->id}}' data-toggle='modal'><span class='glyphicon glyphicon-comment'></span>
			       	      	 </button>

	    
		      <a class='btn btn-primary solid-two ' href="/edit/{{$article->id}}"><span class='glyphicon glyphicon-edit'></span> Edit</a>
				      <button class='btn btn-danger solid-two-light' data-toggle='modal' data-target='#delete-{{$article->id}}'><span class='glyphicon glyphicon-trash'></span></button>
				      <small class='label label-default'>By: {{$article->admin}}</small><small> Posted: {{$article->created_at->diffForHumans()}}</small>
			      </div>
		      </div> 
		      <div class='modal fade' id='delete-{{$article->id}}'> 
				<div class='modal-dialog modal-sm'> 
					<div class='modal-content'> 
						<div class='modal-header' style='background:red; color:white;'> 
							<h3 class='modal-title'>Delete {{$article->tagline}}</h3>
						</div>
						<div class='modal-body' style='max-height:500px; overflow-y:scroll;'> 
							<p>Are you sure you want to delete this article?</p>
						</div>
						<div class='modal-footer'> 
							<button class='del-btn btn btn-danger' data-id="{{$article->id}}" class='btn btn-danger'>Yes</button>
						</div>
						
					</div>
				</div>
			</div>
			 <!---COMMENT MODAL --> 
 	<div class='modal fade' id='comment-modal-{{$article->id}}'> 
				<div class='modal-dialog modal-md'> 
					<div class='modal-content'> 
						<div class='modal-header' style='background:#585858; color:white;'> 
							<h3 class='modal-title'>{{$article->tagline}}</h3>
						</div>
						<div class='modal-body' style='max-height:500px; overflow-y:scroll;'> 
							<div>
								<h4>Comments for "{{$article->tagline}}"</h4>
								
									@foreach($article->comments as $comment)
									<p style='margin:2px;padding:5px; border:solid 0px orange; border-left-width:2px; margin-top:3px;'>
									
									
									<small class='text text-info'><b>{{$comment->name}}</b></small><br>
										<span style='font-style:italic; font-size:1em;color:black;'><b>{{$comment->comment}}</b></span>
										
									</p>
									
									@endforeach
								</div>														
						</div>
						
					</div>
				</div>
			</div>

		      <!---PREVIEW MODAL --> 
			<div class='modal fade' id='preview-modal-{{$article->id}}'> 
				<div class='modal-dialog modal-md'> 
					<div class='modal-content'> 
						<div class='modal-header' style='background:#585858; color:white;'> 
							<h3 class='modal-title'>{{$article->tagline}}</h3>
						</div>
						<div class='modal-body 'style='max-height:500px; overflow-y:scroll;'> 
							<img src="{{asset($article->Image)}}" style='height:350px; width:100%; border:solid 2px gray; border-radius:5px; padding:2px;'>
							<h1>{{$article->tagline}}</h1>
							<h5>{{$article->semiTag}}</h5><small>By: Leroy|Bluh|bluh|bluh</small>
							@if($article->extras==2)
								@php 
									$txtArray = explode('<-->',$article->Text);
									$imgList = explode(',',$article->extraPics);
									foreach($txtArray as $index => $text){
										echo "<p style='whitespace:nowrap;'>$text</p>";
										echo "<img style='height:75%; width:90%'src='$imgList[$index]'>";
									} 
									
																			
									
																									 
									
								@endphp
							
							
							@else
								<p>{{$article->Text}}</p>

							@endif
													
						</div>
						
					</div>
				</div>
			</div>
			
	      	@empty 
	      	
	      	
	      	@endforelse
	     </div>

	   </div>
	  </div>
	</div>
			 
</div>


@endsection 

@section('custom-js') 
	<script>
				
		@if(Session::has('article-img-link'))
			var theLink ="{{Session::get('article-img-link')}}";
	
		@endif
		
		
		$('[data-toggle="popover"]').popover();
		$('#pin-generator').on('click',function(e){
			e.preventDefault();
		});
	</script>
	<script src="{{asset('js/artificial/blog.js')}}"></script>
@endsection 
